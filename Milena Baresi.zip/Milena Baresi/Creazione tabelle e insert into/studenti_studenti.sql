-- MySQL dump 10.13  Distrib 8.0.33, for Win64 (x86_64)
--
-- Host: localhost    Database: studenti
-- ------------------------------------------------------
-- Server version	8.0.33

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `studenti`
--

DROP TABLE IF EXISTS `studenti`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `studenti` (
  `studenti_matricola` int NOT NULL,
  `studenti_nome` varchar(30) NOT NULL,
  `studenti_cognome` varchar(30) NOT NULL,
  `studenti_datanascita` date NOT NULL,
  `studenti_annoiscrizione` int NOT NULL,
  `studenti_via` varchar(30) NOT NULL,
  `studenti_ncivico` int NOT NULL,
  `studenti_cap` int NOT NULL,
  `studenti_ntelefono` int NOT NULL,
  `studenti_citta_codice` int NOT NULL,
  PRIMARY KEY (`studenti_matricola`),
  KEY `studenti_citta_codice` (`studenti_citta_codice`),
  CONSTRAINT `studenti_ibfk_1` FOREIGN KEY (`studenti_citta_codice`) REFERENCES `citta` (`citta_codice`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `studenti`
--

LOCK TABLES `studenti` WRITE;
/*!40000 ALTER TABLE `studenti` DISABLE KEYS */;
INSERT INTO `studenti` VALUES (1,'Milena','Belocchi','2002-02-13',2021,'L. foresti',21,61021,380246789,1),(2,'Paolo','Rossi','2000-04-06',2020,'L. rotti',4,15070,380147956,2),(3,'Luca','Bianchetti','1999-06-07',2022,'L. Nord',6,15066,380952678,4),(4,'Matilde','verdi','2002-06-15',2021,'L. sud',10,13871,380625987,6),(5,'Monica','Provezza','2001-03-07',2023,'L. Est',9,13871,380125469,6);
/*!40000 ALTER TABLE `studenti` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2023-09-08 11:21:36
